C++ Builder projects can statically link to FastMM_FullDebugMode.dll. For that FastMM_FullDebugMode.lib is needed.

- JiYuan Xie